const References = () => {
    let text = `<a href="https://adsecurity.org/?p=1729">https://adsecurity.org/?p=1729</a>
            <a href="http://www.harmj0y.net/blog/redteaming/mimikatz-and-dcsync-and-extrasids-oh-my/">http://www.harmj0y.net/blog/redteaming/mimikatz-and-dcsync-and-extrasids-oh-my/</a>`;
    return { __html: text };
};

export default References;
