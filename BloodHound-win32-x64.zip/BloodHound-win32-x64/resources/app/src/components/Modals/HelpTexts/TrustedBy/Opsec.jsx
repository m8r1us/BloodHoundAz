const Opsec = () => {
    let text = `There is no opsec associated with this edge`;
    return { __html: text };
};

export default Opsec;
