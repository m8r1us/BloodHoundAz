const References = () => {
    let text = `<a href="https://www.specterops.io/assets/resources/an_ace_up_the_sleeve.pdf">https://www.specterops.io/assets/resources/an_ace_up_the_sleeve.pdf</a>
            <a href="https://adsecurity.org/?p=3164">https://adsecurity.org/?p=3164</a>`;
    return { __html: text };
};

export default References;
