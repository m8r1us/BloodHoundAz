const Abuse = () => {
    let text = `No abuse is necessary. This edge simply indicates that a principal belongs to a security group.`;
    return { __html: text };
};

export default Abuse;
