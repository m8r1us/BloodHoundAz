const References = () => {
    let text = `<a href="https://adsecurity.org/?tag=ad-delegation">https://adsecurity.org/?tag=ad-delegation</a><br>
            <a href="https://www.itprotoday.com/management-mobility/view-or-remove-active-directory-delegated-permissions ">https://www.itprotoday.com/management-mobility/view-or-remove-active-directory-delegated-permissions </a>`;
    return { __html: text };
};

export default References;
