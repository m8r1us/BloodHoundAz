const Opsec = () => {
    let text = ``;
    return { __html: text };
};

export default Opsec;
