const References = () => {
    let text = `<a href="https://blog.netspi.com/maintaining-azure-persistence-via-automation-accounts/">https://blog.netspi.com/maintaining-azure-persistence-via-automation-accounts/</a>`;
    return { __html: text };
};

export default References;