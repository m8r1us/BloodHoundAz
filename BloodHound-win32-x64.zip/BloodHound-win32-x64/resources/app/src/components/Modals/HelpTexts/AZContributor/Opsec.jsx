const Opsec = () => {
    let text = `This will depend on which particular abuse you perform, but in general Azure will create a log event for each abuse.`;
    return { __html: text };
};

export default Opsec;