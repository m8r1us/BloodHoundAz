const General = (sourceName, sourceType, targetName, targetType) => {
    let text = `This is an error. Please report this to the BloodHound dev team along with instructions to replicate.`;
    return { __html: text };
};

export default General;
