const Opsec = () => {
    let text = `The Azure activity log for the tenant will log who added what principal to what group, including the date and time.`;
    return { __html: text };
};

export default Opsec;
