const Opsec = () => {
    let text = `Auzre will create a log event whenever a new secret is created for a service principal.`;
    return { __html: text };
};

export default Opsec;
