const References = () => {
    let text = `<a href=""></a>
    <a href=""></a>
    <a href=""></a>`;
    return { __html: text };
};

export default References;
